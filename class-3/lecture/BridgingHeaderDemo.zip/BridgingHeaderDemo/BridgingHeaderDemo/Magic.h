//
//  Magic.h
//  BridgingHeaderDemo
//
//  Created by Adam Wallraff on 12/14/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Magic : NSObject

-(void)showMeMagic;
+(void)sayHiToShai;

@end
