//
//  Magic.m
//  BridgingHeaderDemo
//
//  Created by Adam Wallraff on 12/14/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import "Magic.h"

@implementation Magic

-(void)showMeMagic{
    NSLog(@"POOF!");
}

+(void)sayHiToShai{
    NSLog(@"Hello Magic Shai!");
}

@end
